import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class PacMan extends JFrame {
    private int[][] matrix = PacManMap.loadMapFromFile();

    private int spriteX = 0;
    private int spriteY = 0;

    private Timer movementTimer;
    private int deltaX;
    private int deltaY;
    private int steps;
    private int currentStep;

    private int score = 0;
    private int lives = 3;

    public PacMan() {
        setTitle("Sprite Movement");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        setFocusable(true);

    }

    private void handleKeyPress(KeyEvent e) {
        int keyCode = e.getKeyCode();

        switch (keyCode) {
            case KeyEvent.VK_UP:
                moveSprite(0, -1);
                break;
            case KeyEvent.VK_DOWN:
                moveSprite(0, 1);
                break;
            case KeyEvent.VK_LEFT:
                moveSprite(-1, 0);
                break;
            case KeyEvent.VK_RIGHT:
                moveSprite(1, 0);
                break;
        }
        checkWin();
        checkCoinCollection();
        repaint();
    }

    private void checkWin() {
        int remainingCoins = countRemainingCoins();
        if (remainingCoins == 0) {
            JOptionPane.showMessageDialog(this, "You Win! \n" + " You scored: " + score +"!");
            System.exit(0);
            // --> Return to main menu
        }
    }

    private int countRemainingCoins() {
        int count = 0;
        for (int[] row : matrix) {
            for (int cellValue : row) {
                if (cellValue == 2) {
                    count++;
                }
            }
        }
        return count;
    }


    private void checkCoinCollection() {
        if (matrix[spriteY][spriteX] == 2) {
            matrix[spriteY][spriteX] = 0; // Collect the coin
            System.out.println("Coin collected!");
            score++;
        }
    }
    private void moveSprite(int deltaX, int deltaY) {
        int newSpriteX = spriteX + deltaX;
        int newSpriteY = spriteY + deltaY;

        if (isValidMove(newSpriteX, newSpriteY)) {
            spriteX = newSpriteX;
            spriteY = newSpriteY;
        }
    }

    private boolean isValidMove(int x, int y) {
        if (x >= 0 && x < matrix.length && y >= 0 && y < matrix[0].length) {
            return ((matrix[y][x] == 0) || (matrix[y][x] == 2)) ;
        }
        return false;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        int standardCellSize = 50;
        int coinCellSize = 20; // Adjust this size for the coin cell

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                Color color;
                int currentCellSize;
                int xOffset = 0;
                int yOffset = 0;

                switch (matrix[i][j]) {
                    case 0:
                        color = Color.BLACK;
                        currentCellSize = standardCellSize;
                        break;
                    case 1:
                        color = Color.BLUE;
                        currentCellSize = standardCellSize;
                        break;
                    case 2:
                        color = Color.YELLOW; // Coin color
                        currentCellSize = coinCellSize;
                        // Calculate offsets to center the smaller cell within the bigger cell
                        xOffset = (standardCellSize - coinCellSize) / 2;
                        yOffset = (standardCellSize - coinCellSize) / 2;
                        break;
                    default:
                        color = Color.WHITE;
                        currentCellSize = standardCellSize;
                        break;
                }

                g.setColor(color);
                g.fillRect(j * standardCellSize + xOffset, i * standardCellSize + yOffset, currentCellSize, currentCellSize);
                g.setColor(Color.WHITE);
                g.drawRect(j * standardCellSize + xOffset, i * standardCellSize + yOffset, currentCellSize, currentCellSize);
            }
        }

        g.setColor(Color.YELLOW);
        g.fillOval(spriteX * standardCellSize, spriteY * standardCellSize, standardCellSize, standardCellSize);
    }



    public static void runGame() {
        SwingUtilities.invokeLater(() -> {
            PacMan pacMan = new PacMan();
            pacMan.setVisible(true);
        });
    }
}

